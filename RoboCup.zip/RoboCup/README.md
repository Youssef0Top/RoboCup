# RoboNewbie

NaoTeamHumboldt  http://www.naoteamhumboldt.de

RoboNewbie, version 1.1

August 2016

-------------------------------------------------

Differences to version 1.0 from June 2013 concern:  
- new package agentSoccerTeam (start of a team by the same program)
  and related modifications in other classes.  
- some minor mistakes from version 1.0 were corrected

Some minor mistakes in version 1.1 from February 2015  
have been corrected in September 2015

Some further adaptations are made in August 2016 
Correction for OtherSideGenerator in September 2018

-------------------------------------------------

Parts of this distribution were not developed by NaoTeamHumboldt.

According to their licenses we have used code from  
- magmaOffenburg RoboCup 3D simulation code   
  http://robocup.hs-offenburg.de  
libraries from  
- Apache Commons Math 3.2      
  http://www.apache.org/  

See the related license files in our distribution, which also apply for our code.  
