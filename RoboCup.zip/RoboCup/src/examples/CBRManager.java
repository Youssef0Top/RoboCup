/*package examples;

import java.util.ArrayList;
import java.util.List;

public class CBRManager {
    private List<Case> caseBase;

    public CBRManager() {
        this.caseBase = new ArrayList<>();
    }

    public Case retrieveCase(String currentState) {
        for (Case c : caseBase) {
            if (c.getState().equals(currentState)) {
                return c;
            }
        }
        // Default action if no matching case is found
        return new Case(currentState, "forward", "unknown");
    }

    public void addCase(String state, String action, String outcome) {
        caseBase.add(new Case(state, action, outcome));
    }

    public void displayCases() {
        System.out.println("Current Case Base:");
        for (Case c : caseBase) {
            System.out.println(c);
        }
    }
}
    */
    package examples;

    import java.util.ArrayList;
    import java.util.List;
    
    // CBRManager implementing Real-Time CBR for Keyframe Generation
    public class CBRManager {
        private List<Case> caseMemory; // Memory of Cases
        private AdaptationRules adaptationRules;
    
        public CBRManager() {
            this.caseMemory = new ArrayList<>();
            this.adaptationRules = new AdaptationRules();
        }
    
        // Step 1: Input Real-Time Case Query (Sensors Readings)
        public Case processCase(String currentState) {
            // Step 2: Retrieve Similar Case (Pose)
            Case retrievedCase = retrieveSimilarCase(currentState);
    
            // Step 3: Adapt Case using Adaptation Rules
            Case adaptedCase = adaptationRules.applyRules(retrievedCase, currentState);
    
            // Step 4: Return Adapted Keyframe (Pose)
            return adaptedCase;
        }
    
        // Retrieve the most similar case based on state similarity
        private Case retrieveSimilarCase(String currentState) {
            for (Case c : caseMemory) {
                if (c.getState().equals(currentState)) {
                    return c;
                }
            }
            // Default case if no similar case found
            return new Case(currentState, "stand", "default");
        }
    
        // Add new cases into the case memory
        public void addCase(String state, String action, String outcome) {
            caseMemory.add(new Case(state, action, outcome));
        }
    
        public void displayCases() {
            System.out.println("Current Case Memory:");
            for (Case c : caseMemory) {
                System.out.println(c);
            }
        }
    }
    
    // Separate class for Adaptation Rules
    class AdaptationRules {
        // Apply rules to adapt retrieved case based on current sensor readings
        public Case applyRules(Case retrievedCase, String currentState) {
            String adaptedAction;
    
            // Example rule-based adaptation (modify this based on your needs)
            if (retrievedCase.getAction().equals("forward") && currentState.contains("obstacle")) {
                adaptedAction = "turn";
            } else if (retrievedCase.getAction().equals("stand") && !currentState.contains("obstacle")) {
                adaptedAction = "walk";
            } else {
                adaptedAction = retrievedCase.getAction(); // Default action
            }
    
            return new Case(currentState, adaptedAction, "adapted");
        }
    }
    