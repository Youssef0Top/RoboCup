/* 
package examples;

public class Case {
    private String state;
    private String action;
    private String outcome;

    public Case(String state, String action, String outcome) {
        this.state = state;
        this.action = action;
        this.outcome = outcome;
    }

    public String getState() {
        return state;
    }

    public String getAction() {
        return action;
    }

    public String getOutcome() {
        return outcome;
    }

    @Override
    public String toString() {
        return "State: " + state + ", Action: " + action + ", Outcome: " + outcome;
    }
}
    */
package examples;

public class Case {
    private String state;
    private String action;
    private String outcome;

    public Case(String state, String action, String outcome) {
        this.state = state;
        this.action = action;
        this.outcome = outcome;
    }

    public String getState() {
        return state;
    }

    public String getAction() {
        return action;
    }

    public String getOutcome() {
        return outcome;
    }

    @Override
    public String toString() {
        return "State: " + state + ", Action: " + action + ", Outcome: " + outcome;
    }
}