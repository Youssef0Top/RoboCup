package examples;

import agentIO.EffectorOutput;
import agentIO.PerceptorInput;
import agentIO.ServerCommunication;
import keyframeMotion.KeyframeMotion;
import directMotion.LookAroundMotion;
import examples.agentSimpleSoccer.Agent_SimpleSoccer;
import examples.agentSimpleSoccer.SoccerThinking;
import localFieldView.LocalFieldView;
import java.io.IOException;
import java.util.logging.Level;
import util.Logger;

public class RoboAgent {
    private String playerId;
    private String teamName;
    private double beamX, beamY, beamRot;
    private EffectorOutput effOut;
    private PerceptorInput percIn;
    private KeyframeMotion motion;
    private LocalFieldView localView;
    private SoccerThinking soccerThinking;
    private LookAroundMotion lookAround;
    private Logger log;
    private CBRManager cbrManager;

    public RoboAgent(String playerId, String teamName, double beamX, double beamY, double beamRot) {
        this.playerId = playerId;
        this.teamName = teamName;
        this.beamX = beamX;
        this.beamY = beamY;
        this.beamRot = beamRot;
        this.cbrManager = new CBRManager();
    }

    // Initialize the agent components
    public void init() {
        ServerCommunication sc = new ServerCommunication();

        this.log = new Logger();
        this.percIn = new PerceptorInput(sc);
        this.effOut = new EffectorOutput(sc);
        this.motion = new KeyframeMotion(effOut, percIn, log);
        this.localView = new LocalFieldView(percIn, log, teamName, playerId);
        this.lookAround = new LookAroundMotion(percIn, effOut, log);
        this.soccerThinking = new SoccerThinking(percIn, localView, motion, log);

        // Initialize the robot with the server
        sc.initRobot(playerId, teamName, beamX, beamY, beamRot);
        System.out.println("Player initialized: " + playerId);
    }

    // Run the agent for the given time
    public void run() {
        int agentRunTimeInSeconds = 1200;
        int totalServerCycles = agentRunTimeInSeconds * 50;

        // Synchronize the agent with the server for the entire runtime
        for (int i = 0; i < totalServerCycles; i++) {
            if (shouldAbort()) break;

            sense();
            think();
            act();
            walkForward();
            stopWalking();
            //fallBack();
            //fallForward();
            standUpFromBack();
            rollOverToBack();
            percIn.update();
            String currentState = percIn.toString();

            // Retrieve a case from CBR
            Case retrievedCase = cbrManager.retrieveCase(currentState);
            String action = retrievedCase.getAction();
            if (action.equals("forward")) {
                walkForward();
            } else if (action.equals("turn")) {
                motion.setTurnLeft();
            } else {
                stopWalking();
            }

            // Execute motions
            motion.executeKeyframeSequence();
            lookAround.look();
            effOut.sendAgentMessage();

            // Learn new cases
            cbrManager.addCase(currentState, action, "success");
        }
    }

    // Sense the environment (update perceptor and field view)
    private void sense() {
        percIn.update();
        localView.update();
    }

    // Think about the next move (decide the action)
    private void think() {
        soccerThinking.decide();
    }

    // Act based on the decision made (execute motion and send commands)
    private void act() {
        motion.executeKeyframeSequence();
        lookAround.look(); // Always turn the head after executing motion
        effOut.sendAgentMessage();
    }

    // Check if the agent should abort (via user input from the console)

    // Execute a specific action using a keyframe sequence
    private void walkForward() {
        motion.setWalkForward();
    }

    private void stopWalking() {
        motion.setStopWalking();
    }
 
    private void fallBack() {
        motion.setFallBack();
    }

    private void fallForward() {
        motion.setFallForward();
    }

    private void standUpFromBack() {
        motion.setStandUpFromBack();
    }

    private void rollOverToBack() {
        motion.setRollOverToBack();
    }

    // Check if the agent should abort (via user input from the console)
    private boolean shouldAbort() {
        try {
            return System.in.available() != 0;
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(Agent_SimpleSoccer.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    // Print the agent's log (if necessary)
    public void printLog() {
        log.printLog();
    }
}