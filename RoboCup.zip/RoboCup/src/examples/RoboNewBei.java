/* 
package examples;

import agentIO.EffectorOutput;
import agentIO.PerceptorInput;
import agentIO.ServerCommunication;
import util.RobotConsts;

public class RoboNewBei {
    public static void main(String[] args) {
        // Initialize ServerCommunication
        ServerCommunication serverComm = new ServerCommunication(); // Adjust IP and port if needed

        // Pass ServerCommunication to constructors
        PerceptorInput input = new PerceptorInput(serverComm);
        EffectorOutput output = new EffectorOutput(serverComm);
        CBRManager cbrManager = new CBRManager();

        while (true) {
            // 1. Read sensor inputs
            input.update(); // Replace with the correct method in PerceptorInput
            String currentState = input.toString(); // Simplified state as string
            
            // 2. Retrieve the most similar case
            Case retrievedCase = cbrManager.retrieveCase(currentState);
            String action = retrievedCase.getAction();

            // 3. Take action based on the case
            if (action.equals("forward")) {
                output.setJointCommand(RobotConsts.LeftShoulderPitch, 0.5);
                output.setJointCommand(RobotConsts.RightShoulderPitch, 0.5);
            } else if (action.equals("turn")) {
                output.setJointCommand(RobotConsts.LeftHipYawPitch, 0.3);
                output.setJointCommand(RobotConsts.RightHipYawPitch, -0.3);
            } else {
                // Example stop command: reset velocities
                output.setJointCommand(RobotConsts.LeftShoulderPitch, 0.0);
                output.setJointCommand(RobotConsts.RightShoulderPitch, 0.0);
            }

            // Send commands to the server
            output.sendAgentMessage();

            // 4. Store new cases (example: assume all actions are successful)
            String outcome = "success"; 
            cbrManager.addCase(currentState, action, outcome);
            
            // Display the current case base for debugging
            cbrManager.displayCases();
        }
    }
}
*/
package examples;

import agentIO.EffectorOutput;
import agentIO.PerceptorInput;
import agentIO.ServerCommunication;
import util.RobotConsts;

public class RoboNewBei {
    public static void main(String[] args) {
        // Initialize ServerCommunication
        ServerCommunication serverComm = new ServerCommunication(); // Adjust IP and port if needed

        // Pass ServerCommunication to constructors
        PerceptorInput input = new PerceptorInput(serverComm);
        EffectorOutput output = new EffectorOutput(serverComm);
        CBRManager cbrManager = new CBRManager();

        while (true) {
            // 1. Read sensor inputs
            input.update(); // Replace with the correct method in PerceptorInput
            String currentState = input.toString(); // Simplified state as string

            // 2. Retrieve the most similar case
            Case retrievedCase = cbrManager.retrieveCase(currentState);
            String action = retrievedCase.getAction();

            // 3. Take action based on the case
            if (action.equals("forward")) {
                output.setJointCommand(RobotConsts.LeftShoulderPitch, 0.5);
                output.setJointCommand(RobotConsts.RightShoulderPitch, 0.5);
            } else if (action.equals("turn")) {
                output.setJointCommand(RobotConsts.LeftHipYawPitch, 0.3);
                output.setJointCommand(RobotConsts.RightHipYawPitch, -0.3);
            } else {
                // Example stop command: reset velocities
                output.setJointCommand(RobotConsts.LeftShoulderPitch, 0.0);
                output.setJointCommand(RobotConsts.RightShoulderPitch, 0.0);
            }

            // Send commands to the server
            output.sendAgentMessage();

            // 4. Store new cases (example: assume all actions are successful)
            String outcome = "success"; 
            cbrManager.addCase(currentState, action, outcome);
            
            // Display the current case base for debugging
            cbrManager.displayCases();
        }
    }
}