package examples;

import java.util.ArrayList;
import java.util.List;

public class RoboTeam {
    private String teamName;
    private List<RoboAgent> agents;
    private CBRManager sharedCBR;

    public RoboTeam(String teamName) {
        this.teamName = teamName;
        this.agents = new ArrayList<>();
        this.sharedCBR = new CBRManager();
    }

    // Add agents to the team
    public void addAgent(String playerId, double beamX, double beamY, double beamRot, String role) {
        RoboAgent agent = new RoboAgent(playerId, teamName, beamX, beamY, beamRot);
        agents.add(agent);
    }

    // Initialize all agents in the team
    public void initTeam() {
        for (RoboAgent agent : agents) {
            agent.init();
        }
    }

    // Run all agents in parallel
    public void runTeam() {
        for (final RoboAgent agent : agents) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    agent.run();
                }
            }).start();
        }
    }
    public void displaySharedCases() {
        System.out.println("Shared Case Base:");
        sharedCBR.displayCases();
    }

    // Print logs for all agents
    public void printLogs() {
        for (RoboAgent agent : agents) {
            agent.printLog();
        }
    }

    public static void main(String[] args) {
        // Initialize Team A
        final RoboTeam teamA = new RoboTeam("TeamA");
        teamA.addAgent("Player1", -1, 0, 0, "Striker");
        teamA.addAgent("Player2", -1, 1, 0, "Defender");
        teamA.addAgent("Player3", -1, -1, 0, "Midfielder");
        teamA.addAgent("Player4", -2, 0, 0, "Goalkeeper");

        // Initialize Team B
        final RoboTeam teamB = new RoboTeam("TeamB");
        teamB.addAgent("Player5", 1, 0, 180, "Striker");
        teamB.addAgent("Player6", 1, 1.5, 180, "Defender");
        teamB.addAgent("Player7", 1, -1.5, 180, "Midfielder");
        teamB.addAgent("Player8", 2, 0, 180, "Goalkeeper");

        // Start and run both teams
        System.out.println("Initializing Team A...");
        teamA.initTeam();

        System.out.println("Initializing Team B...");
        teamB.initTeam();

        System.out.println("Starting Team A...");
        teamA.runTeam();

        System.out.println("Starting Team B...");
        teamB.runTeam();

        // Wait for a moment to allow teams to run, then print logs
        try {
            Thread.sleep(5000); // Allow time for the agents to perform actions
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Printing logs for Team A:");
        teamA.printLogs();

        System.out.println("Printing logs for Team B:");
        teamB.printLogs();

        System.out.println("Agents stopped.");
    }
}

/*
 public static void main(String[] args) {
        // Initialize Team A
        final RoboTeam teamA = new RoboTeam("TeamA");
        teamA.addAgent("Player1", -1, 0, 0, "Striker");
        teamA.addAgent("Player2", -1, 1, 0, "Defender");
        teamA.addAgent("Player3", -1, -1, 0, "Midfielder");
        teamA.addAgent("Player4", -2, 0, 0, "Goalkeeper");

        // Initialize Team B
        final RoboTeam teamB = new RoboTeam("TeamB");
        teamB.addAgent("Player5", 1, 0, 180, "Striker");
        teamB.addAgent("Player6", 1, 1.5, 180, "Defender");
        teamB.addAgent("Player7", 1, -1.5, 180, "Midfielder");
        teamB.addAgent("Player8", 2, 0, 180, "Goalkeeper");

        // Start both teams sequentially in separate threads
        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Starting Team A");
                teamA.startTeam("TeamA"); // Start Team A
            }
        }).start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Starting Team B");
                teamB.startTeam("TeamB"); // Start Team B
            }
        }).start();
    }
 */