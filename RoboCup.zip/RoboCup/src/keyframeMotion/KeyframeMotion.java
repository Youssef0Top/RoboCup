/*******************************************************************************
*  RoboNewbie
* NaoTeam Humboldt
* @author Monika Domanska, 
* extended with motions for agentSoccerTeam, hdb 16.10.2014
* @version 1.1
* 
* changed hdb 14.19.2016
*******************************************************************************/

package keyframeMotion;

import agentIO.EffectorOutput;
import agentIO.PerceptorInput;
import keyframeMotion.util.Keyframe;
import keyframeMotion.util.KeyframeFileHandler;
import keyframeMotion.util.KeyframeSequence;
import util.Logger;
import util.RobotConsts;

/** 
 * Motions for the robot by processing of keyframe sequences.
 * 
 * An object of class KeyframeMotion loads robot movements (like "walking two 
 * steps" or "turning the head" etc.) from .txt-files and provides methods for 
 * applying these movements. 
 * 
 * Usage (usually during the think()-method of the agent class):
 * 1) Method ready(): Before a movement can be chosen, call ready() to check,
 * if the robot currently executes a move.
 * 2) Methods set...(): Choose a movement with one of the set...() methods 
 * (like setWalkForward()). This can be done only after the ready()-call, 
 * because otherwise the current movement would be aborted suddenly, so for 
 * example the robot would fall down while doing a walking step.
 * The setTest() method is a specific feature for testing new keyframe 
 * sequences. 
 * 3) At any time the method setLogging(...) can be executed to turn the 
 * logging of chosen moves on or off. If the logging is turned on, every time, 
 * when a move is set, the name of the move is logged. 
 *  
 * Required context in the agent class: 
 * The agent class must have an object of class EffectorOutput and one of class
 * PerceptorInput, and they must be used correctly as explained in the comments
 * on the classes.
 * In the act()-method of the agent class: method 
 * KeyframeMotion.executeKeyframeSequence() must be called before the
 * EffectorOutput-method sendAgentMessage().
 * An example for a correct usage context of KeyframeMotion is class
 * Agent_SimpleWalkToBall in package examples.agentSimpleWalkToBall.
 * 
 * Integrating new motions to the implementation of this class:
 * 1) Save the new keyframe sequence in folder 
 * "[RoboNewbie project folder]/keyframes/" .
 * 2) Add a new class variable to KeyframeMotion just like WALK_FORWARD_SEQUENCE.
 * 3) Extend the constructor to load the new sequence into the new variable.
 * 4) Add a new set...() method just like setWalkForward(). (Not like setTest()!)
 * 
 * Using KeyframeMotion together with other motion implementations:
 * As mentioned above, method executeKeyframeSequence() has to be called in
 * every cycle. After this call, there are set commands for every joint
 * effector. Other motion classes can overwrite the commands with the
 * EffectorOutput instance of the agent.
 * See also the comment on method executeKeyframeSequence() and on class
 * EffectorOutput. Example: In Agent_SimpleSoccer.java (especially method act())
 * in package examples.agentSimpleSoccer another motion class is used together
 * with KeyframeMotion.
 */
public class KeyframeMotion {

  private enum MotionState {
    IN_FRAME, BETWEEN_FRAMES, READY_TO_MOVE
  }
  private static final double ANGLE_TOLLERANCE = 8f;
  
  //time between two server messages in ms
  private static final int TIME_STEMP_INTERVAL = 20; 
  
  private final PerceptorInput percIn;
  private final EffectorOutput effOut;
  private final Logger log;
  boolean loggingOn;
  private static KeyframeSequence WALK_FORWARD_SEQUENCE;
  private static KeyframeSequence FALL_BACK_SEQUENCE;
  private static KeyframeSequence FALL_FORWARD_SEQUENCE;
  private static KeyframeSequence STAND_UP_FROM_BACK_SEQUENCE;
  private static KeyframeSequence ROLL_OVER_TO_BACK_SEQUENCE;
  private static KeyframeSequence STOP_WALKING_SEQUENCE;
  private static KeyframeSequence TURN_RIGHT_SEQUENCE;
  private static KeyframeSequence TURN_LEFT_SEQUENCE;
  private static KeyframeSequence TURN_RIGHT_SMALL_SEQUENCE;
  private static KeyframeSequence TURN_LEFT_SMALL_SEQUENCE;
  private static KeyframeSequence SIDE_STEP_RIGHT_SEQUENCE;
  private static KeyframeSequence SIDE_STEP_LEFT_SEQUENCE;
  private static KeyframeSequence TURN_HEAD_LEFT_SEQUENCE;
  private static KeyframeSequence TURN_HEAD_RIGHT_SEQUENCE;
  private static KeyframeSequence TURN_HEAD_DOWN_SEQUENCE;
  private static KeyframeSequence WAVE_SEQUENCE;
  
  private static KeyframeSequence KICK_RIJEKA2013_SEQUENCE;
  private static KeyframeSequence WALK_FORWARD_RIJEKA2013_SEQUENCE;
  private static KeyframeSequence BAD_WALK_PLOVDIV2014_SEQUENCE;
  private static KeyframeSequence ALPHA_KICK_PLOVDIV2014_SEQUENCE; 
  private static KeyframeSequence STOP_WALKING_PLOVDIV2014_SEQUENCE;
  
  private static KeyframeSequence RETURN_TO_INITIAL_POSE_SEQUENCE;
  
  
  private Keyframe actualKeyframe = null;         // These three variables could  
  private int leftCyclesForActualFrame = 0;       // be used instead of state.
  private KeyframeSequence actualSequence = null; // But then the code becomes less clear.
  private MotionState state = MotionState.READY_TO_MOVE;
  
  private double[] lastCycleAngles = new double[RobotConsts.JointsCount];

  /**
   * Constructor, initialize dependencies and load movements. 
   * 
   * Sets the required dependencies for logging and sending 
   * effector commands to the server and loads all movements from the keyframe 
   * sequence files. 
   * 
   * @param effOut Has to be already initialized, cannot be null. 
   * @param percIn Has to be already initialized, cannot be null. 
   * @param logger Has to be already initialized, cannot be null. 
   * 
   */
  public KeyframeMotion(EffectorOutput effOut, PerceptorInput percIn, Logger logger) {
    this.effOut = effOut;
    this.percIn = percIn;
    log = logger;
    loggingOn = false;
    for (int i = 0; i < lastCycleAngles.length; i++) 
      lastCycleAngles[i] = 0;

    KeyframeFileHandler keyframeReader = new KeyframeFileHandler();

    WALK_FORWARD_SEQUENCE = keyframeReader.getSequenceFromFile("walk_forward-flemming-nika.txt");
    FALL_BACK_SEQUENCE = keyframeReader.getSequenceFromFile("nika_fall_back.txt");
    FALL_FORWARD_SEQUENCE = keyframeReader.getSequenceFromFile("fall_forward.txt");
    STAND_UP_FROM_BACK_SEQUENCE = keyframeReader.getSequenceFromFile("stand_up_from_back.txt");
    ROLL_OVER_TO_BACK_SEQUENCE = keyframeReader.getSequenceFromFile("roll_over_to_back.txt");
    STOP_WALKING_SEQUENCE = keyframeReader.getSequenceFromFile("nika_stop_walking.txt");
    TURN_RIGHT_SEQUENCE = keyframeReader.getSequenceFromFile("turn-right-nika.txt");
    TURN_LEFT_SEQUENCE = keyframeReader.getSequenceFromFile("turn-left-nika.txt");
    TURN_RIGHT_SMALL_SEQUENCE = keyframeReader.getSequenceFromFile("turn-right-small-nika.txt");
    TURN_LEFT_SMALL_SEQUENCE = keyframeReader.getSequenceFromFile("turn-left-small-nika.txt");
    SIDE_STEP_RIGHT_SEQUENCE = keyframeReader.getSequenceFromFile("side-step-right-nika.txt");
    SIDE_STEP_LEFT_SEQUENCE = keyframeReader.getSequenceFromFile("side-step-left-nika.txt");
    TURN_HEAD_LEFT_SEQUENCE = keyframeReader.getSequenceFromFile("turn-head-left.txt");
    TURN_HEAD_RIGHT_SEQUENCE = keyframeReader.getSequenceFromFile("turn-head-right.txt");
    TURN_HEAD_DOWN_SEQUENCE = keyframeReader.getSequenceFromFile("turn-head-down.txt");
    WAVE_SEQUENCE = keyframeReader.getSequenceFromFile("wave_nika.txt");
    
    KICK_RIJEKA2013_SEQUENCE = keyframeReader.getSequenceFromFile("kick_Rijeka2013.txt");
    WALK_FORWARD_RIJEKA2013_SEQUENCE = keyframeReader.getSequenceFromFile("walk_forward_Rijeka2013.txt");
    BAD_WALK_PLOVDIV2014_SEQUENCE = keyframeReader.getSequenceFromFile("faster_ns_walk_Plovdiv2014.txt");
    ALPHA_KICK_PLOVDIV2014_SEQUENCE = keyframeReader.getSequenceFromFile("alpha_kick_Plovdiv2014.txt");
    STOP_WALKING_PLOVDIV2014_SEQUENCE = keyframeReader.getSequenceFromFile("stop_walking_Plovdiv2014.txt");
   
    
    RETURN_TO_INITIAL_POSE_SEQUENCE = keyframeReader.getSequenceFromFile("reset_initial_pose.txt");
  }
  public void resetToInitialPose() {
    if (loggingOn) log.log("motion reset to initial pose\n");
    actualSequence = RETURN_TO_INITIAL_POSE_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;

    while (!ready()) {
        executeKeyframeSequence();
        effOut.sendAgentMessage();
        try {
            Thread.sleep(50); // Allow the server to process commands
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    System.out.println("Robot reset to initial pose successfully.");
}


  /**
   * Turn logging of set moves on or off. 
   * 
   * When the logging is turned on, a log entry is generated every time when a 
   * move is set.
   * 
   * @param b Pass b=true to turn the logging on, and b=false to turn it off.  
   */
  public void setLogging(boolean b){
    loggingOn = b;
  }
  
  /**
   * Set move to turn the robots head down.
   * 
   * Assumed posture before this move: could be any.
   */
  public void setTurnHeadDown() {
    if (loggingOn) log.log("motion turn head down \n");
    actualSequence = TURN_HEAD_DOWN_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }

  /**
   * Set move to turn the robots head to the left as far as possible.
   * 
   * Assumed posture before this move: could be any.
   */
  public void setTurnHeadLeft() {
    if (loggingOn) log.log("motion turn head left \n");
    actualSequence = TURN_HEAD_LEFT_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
  
  /**
   * Set move to turn the robots head to the right as far as possible.
   * 
   * Assumed posture before this move: could be any. 
   */
  public void setTurnHeadRight() {
    if (loggingOn) log.log("motion turn head right \n");
    actualSequence = TURN_HEAD_RIGHT_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
  
  
  /**
   * Set move for walking one turning right step (about 30 degrees).
   * 
   * Assumed posture before this move: the robot is standing on parallel feet.
   */
  public void setTurnRight() {
    if (loggingOn) log.log("motion turn right \n");
    actualSequence = TURN_RIGHT_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }

  /**
   * Set move for walking one turning left step (about 30 degrees).
   * 
   * Assumed posture before this move: the robot is standing on closed parallel 
   * feet.
   */
  public void setTurnLeft() {
    if (loggingOn) log.log("motion turn left \n");
    actualSequence = TURN_LEFT_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
  
  /**
   * Set move for walking one small turning right step (about 6-8 degrees).
   * 
   * Assumed posture before this move: the robot is standing on parallel feet.
   */
  public void setTurnRightSmall() {
    if (loggingOn) log.log("motion turn right small\n");
    actualSequence = TURN_RIGHT_SMALL_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }

  /**
   * Set move for walking one small turning left step (about 6-8 degrees).
   * 
   * Assumed posture before this move: the robot is standing on closed parallel 
   * feet.
   */
  public void setTurnLeftSmall() {
    if (loggingOn) log.log("motion turn left small\n");
    actualSequence = TURN_LEFT_SMALL_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
  
    /**
   * Set move for walking one side step to the right.
   * 
   * Assumed posture before this move: the robot is standing on parallel feet.
   */
  public void setSideStepRight() {
    if (loggingOn) log.log("motion side step right \n");
    actualSequence = SIDE_STEP_RIGHT_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }

  /**
   * Set move for walking one side step to the left.
   * 
   * Assumed posture before this move: the robot is standing on closed parallel 
   * feet.
   */
  public void setSideStepLeft() {
    if (loggingOn) log.log("motion side step left \n");
    actualSequence = SIDE_STEP_LEFT_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
  
  /**
   * Set move for walking two steps forward.
   * 
   * Assumed posture before this move: the robot is standing on closed parallel 
   * feet or has just completed the same walk forward movement.
   * 
   * To return to parallel feet after walking use method setStopWalking().
   */
  public void setWalkForward() {
    if (loggingOn) log.log("motion walk forward \n");
    actualSequence = WALK_FORWARD_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }

  /**
   * Set move to let the robot stop with parallel feed after walking forward.
   * 
   * Assumed posture before this move: the robot has just completed the walking
   * sequence and stands on one foot stretched out to the front and one to the
   * back.
   * 
   * After this move the robot stands on closed parallel feet.
   */
  public void setStopWalking() {
    if (loggingOn) log.log("motion stop walking \n");
    actualSequence = STOP_WALKING_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
  
  /**
   * Set move to let the robot fall down on its back.
   * 
   * Assumed posture before this move: the robot is in an upright position.
   */
  public void setFallBack() {
    if (loggingOn) log.log("motion fall back \n");
    actualSequence = FALL_BACK_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
  
  /**
   * Set move to let the robot fall down on its front side.
   * 
   * Assumed posture before this move: the robot is in an upright position.
   */
  public void setFallForward() {
    if (loggingOn) log.log("motion fall forward \n");
    actualSequence = FALL_FORWARD_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }

  /**
   * Set move for standing up, when the robot lies on its back.
   * 
   * Assumed posture before this move: the robot lies on its back.
   * After this move the robot stands on closed parallel feet.
   */
  public void setStandUpFromBack() {
    if (loggingOn) log.log("motion stand up from back \n");
    actualSequence = STAND_UP_FROM_BACK_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
  
  /**
   * Set move for rolling over the lying robot to its back.
   * 
   * Assumed posture before this move: the robot lies on its front. 
   * This move might have to be executed several times.
   */
   public void setRollOverToBack() {
    if (loggingOn) log.log("motion roll over from back \n");
    actualSequence = ROLL_OVER_TO_BACK_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
   
  /**
   * Set move waving.
   * 
   * Assumed posture before this move: the robot is in an upright position.
   */
   public void setWave() {
    if (loggingOn) log.log("motion wave \n");
    actualSequence = WAVE_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
   
   /**
   * kick method from Rijeka 2013, medium kick
   */
  public void setKick_Rijeka2013() {
    if (loggingOn) log.log("motion kick from Rijeka 2013 \n");
    actualSequence = KICK_RIJEKA2013_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
  
    /**
   * walk method derived from from Rijeka 2013. 
   * The original walk is combined from separate keyframes 
   * with begin, left, right, left-end, right-end
   * which results in a more smooth walk.
   * The keyframe used here is simply the concatenation of left and right.
   */
  public void setWalkForward_Rijeka2013() {
    if (loggingOn) log.log("motion walk from Rijeka 2013 \n");
    actualSequence = WALK_FORWARD_RIJEKA2013_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
  
  /**
   * walk method from Plovdiv
   */
  public void setBadWalk_Plovdiv2014() {
      if (loggingOn) log.log("motion walk fast from Plovdiv \n");
    actualSequence = BAD_WALK_PLOVDIV2014_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  } 
   
   
   /**
   * kick method from Plovdiv 2014, very strong kick
   */
  public void setKick_Plovdiv2014() {
    if (loggingOn) log.log("motion kick the ball from Plovdiv \n");
    actualSequence = ALPHA_KICK_PLOVDIV2014_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
  }
   
   /**
   * stop walking method from Plovdiv 2014, shorter than the Nika version
   */
  
  public void setStopWalking_Plovdiv2014() {
    if (loggingOn) log.log("motion stop walking Plovdiv 2014 \n");
    actualSequence = STOP_WALKING_PLOVDIV2014_SEQUENCE;
    state = MotionState.BETWEEN_FRAMES;
    }

    /*
     * Two defense actions of a goalie. The keyframe motions were implemented by
     * Team "Hertha Berlin". It was champion in the course competition in Rijeka
     * 2016. Team "Hertha Berlin": Jan Božić, Edvin Močibob, Matej Šamanić,
     * Tomislav Šubić.
     */
  

    /**
     * Sets the pose back to initial pose:  all joint angles set to 0.
     * Should be used e.g. before beam
     * commands to overwrite ongoing motion
     */
    public void setReturnToInitialPose() {
        if (loggingOn) {
            log.log("motion return to initial pose \n");
        }
        actualSequence = RETURN_TO_INITIAL_POSE_SEQUENCE;
        state = MotionState.BETWEEN_FRAMES;
    }

  /**
   * Load a test motion from file test.txt and set it for execution. 
   * 
   * The motion has to be in file "[RoboNewbie project folder]/keyframes/test.txt".
   * 
   * This setter method differs from the other ones concerning the loading: The
   * keyframe-file test.txt is read with each new call of the motion "Test". 
   * So the file test.txt can be edited during the runtime of the agent 
   * program and changes in the movement are visible immediately after the next
   * call of this method. This allows to change the keyframe-file without a new 
   * start of the agent.
   * It is used in this way by the class Agent_KeyframeDeveloper. 
   */
  public void setTest() {
    if (loggingOn) log.log("motion Test\n");
    KeyframeFileHandler keyframeReader 
            = new KeyframeFileHandler();
    actualSequence = keyframeReader.getSequenceFromFile("test.txt");
    state = MotionState.BETWEEN_FRAMES;
  }

  /**
   * States, whether the robot is ready to start a new movement or is currently 
   * busy with a movement.
   * 
   * @return True, if the robot is ready for setting a new movement. Else false,
   * if the robot currently executes a sequence. 
   */
  public boolean ready() {
    if (state == MotionState.READY_TO_MOVE) {
      return true;
    } else {
      return false;
        }
    }

    /**
     * Stops the current movement. Can be called by AgentSoccerTeam in playmode
     * Goal_Left or Goal_Right before beaming, such that robot does not try to
     * continue afterwards hdb 14.10.2016
     */
    public void stopMotion() {
        state = MotionState.READY_TO_MOVE;
        /*
         * toDo: complete. 
         * state = MotionState.READY_TO_MOVE;
         * keyframeMotion.util.KeyframeSequence.reset_nextFrameNumber();
         * actualKeyframe = null;
         * what more?
         *
         * IMPORTANT: set all joint speeds to 0  (stop all motions)
         */
    }

  /**
   * Executes the actually set movement (also callable if there is not set any 
   * movement).
   * 
   * Continues the current movement over all planned server cycles, means that
   * this method activates the functionalities to 
   * - translate the data in a keyframe sequence to effector commands for the
   * actual server cycle
   * and 
   * - set the joint commands, which should be sent to the server in the actual
   * server cycle.
   * 
   * Note that here are set commands for all joints of the robot, even for the
   * joints, that are not changed during the set move. E.g. if the walking move
   * is chosen for execution, than the commands for the head will be set, too, 
   * in every server cycle, when this method is executed. 
   * 
   * If there is not set any movement, there are not set any commands. 
   */
  public void executeKeyframeSequence() {  
      
    switch (state) {
      case READY_TO_MOVE:
        break;
      case BETWEEN_FRAMES:
        setActualKeyframe();
        break;
      case IN_FRAME:
        executeActualKeyframe();
        break;
    }
  }

  /**
   * Internal method for choosing the actual keyframe from the actual sequence.
   * Sets the internal state of KeyframeMotion indicating if motion is finished.
   */
  private void setActualKeyframe() {

//    if (actualKeyframe != null) {
//      log.log("setActKey");
//      log.log(actualKeyframe.getDebugString());
//      log.log(percIn.getJointsDebugString() + "\n");
//    }

    actualKeyframe = actualSequence.getNextFrame();
    if (actualKeyframe == null) {
      actualSequence = null;
      state = MotionState.READY_TO_MOVE;
      //log.log("ende der seq");
    } else {
      for (int i = 0; i < lastCycleAngles.length; i++) 
        lastCycleAngles[i] = 0;
      leftCyclesForActualFrame = actualKeyframe.getTransitionTime() / TIME_STEMP_INTERVAL;
      
      state = MotionState.IN_FRAME;
      executeActualKeyframe();

//            log.log("setActKeyfr.. frame:");
//            StringBuilder returnString = new StringBuilder();
//            returnString.append(actualKeyframe.getTransitionTime()).append(' ');            
//            for (int i = 0; i < RobotConsts.JointsCount; i++){
//                returnString.append(RobotConsts.getEffectorName(i));
//                returnString.append('=');
//                returnString.append(actualKeyframe.getAngle(i));
//                returnString.append(' ');
//            }
//            log.log(returnString.toString());
    }
  }

  /**
   * Internal method for initiating the translation from a keyframe sequence to 
   * effector commands and setting the actual commands for this cycle.
   * 
   * -------------------------
   *  A keyframe is reached within several cycles. The number of cycles depends
   * on the transition time specified in the keyframe.
   * Sets the internal state of KeyframeMotion indicating if the motion is completed.
   */
  private void executeActualKeyframe() {

    double[] newCommands = new double[RobotConsts.JointsCount];
    state = MotionState.BETWEEN_FRAMES;

    for (int i = 0; i < RobotConsts.JointsCount; i++) {
      newCommands[i] =
              getSpeedFromAngleAndTime(i);
      if (newCommands[i] != 0f) {
        state = MotionState.IN_FRAME;
      }
    }
//      Debug output for effector commands (see also below)
//        StringBuilder builder = new StringBuilder();
//        builder.append("cycles left ").append(leftCyclesForActualFrame).append(' ');
//        for (int i = 0; i < RobotConsts.JointsCount; i++) {
//            builder.append(RobotConsts.getEffectorName(i)).append(' ');
//            if (Math.abs(newCommands[i]) < 0.001) 
//                builder.append(0);
//            else
//                builder.append(newCommands[i]);
//            builder.append("  ");
//        }
//        log.log(builder.toString());   
        //log.log(percIn.getJointsDebugString());
        
    effOut.setAllJointCommands(newCommands);
    leftCyclesForActualFrame--;


//        Debug output für verification of a keyframe reader or for testing of a new sequence. 

//    if (state == MotionState.BETWEEN_FRAMES) {
//      log.log("exeActKey");
//      log.log(actualKeyframe.getDebugString());
//      log.log(percIn.getJointsDebugString());
//      log.log("\n");
//    }
  }

  /**
   * Internal method for translating data from a keyframe sequence to effector
   * commands.
   * 
   * Calculates for a joint the effector command, that should be executed in the
   * actual server cycle. 
   * 
   * @param angleIndex Index of the joint as defined in util.RobotConsts
   * @see util.RobotConsts
   */
  private double getSpeedFromAngleAndTime(int angleIndex) {
    double speed = 0f;

    double targetAngle = actualKeyframe.getAngle(angleIndex);
    double sensedAngle = Math.toDegrees(percIn.getJoint(angleIndex));
    
    if (leftCyclesForActualFrame > 1) {
      double angleDifference = 
              targetAngle - (sensedAngle + lastCycleAngles[angleIndex]);
              // Considering lastCycleAngles is important, because the 
              // server sends joint perceptor values (like all perceptor values)
              // delayed by one simulation step.
      double thisCycleAngle = 
              (angleDifference ) / (double)(leftCyclesForActualFrame - 1);
              // cycles - 1, because the last command is always 0
      speed =  (Math.toRadians(thisCycleAngle) / (double) TIME_STEMP_INTERVAL) * (double)1000;
              // multiplication by 1000, because speed has to be per sec, 
              // not per ms.
      lastCycleAngles[angleIndex] = thisCycleAngle;
    }

    return speed;
  }
}
