import agentIO.EffectorOutput;
import agentIO.PerceptorInput;
import agentIO.ServerCommunication;
import util.RobotConsts;

public class RoboAgent {
    private String playerId;
    private String teamName;
    private double beamX, beamY, beamRot;
    private String role;
    private EffectorOutput effOut;
    private PerceptorInput percIn;

    public RoboAgent(String playerId, String teamName, double beamX, double beamY, double beamRot, String role) {
        this.playerId = playerId;
        this.teamName = teamName;
        this.beamX = beamX;
        this.beamY = beamY;
        this.beamRot = beamRot;
        this.role = role;

        ServerCommunication sc = new ServerCommunication(); // SimSpark server address
        this.effOut = new EffectorOutput(sc);
        this.percIn = new PerceptorInput(sc);

        // Initialize robot on the field
        sc.initRobot(playerId, teamName, beamX, beamY, beamRot);
    }

    public void runAgent(String kickoffTeam) {
        while (true) {
            percIn.update(); // Get sensor data
            if (teamName.equals(kickoffTeam)) {
                performKickoffRole(); // Robots on the kickoff team execute kickoff logic
            } else {
                performOpponentRole(); // Robots on the non-kickoff team react to the kickoff
            }
            effOut.sendAgentMessage(); // Send commands to the server
        }
    }

    private void performKickoffRole() {
        if (role.equals("Striker")) {
            moveToBall(); // Example: move towards the ball
            if (isCloseToBall()) {
                kickBall();
            }
        } else if (role.equals("Midfielder")) {
            supportKickoff();
        } else if (role.equals("Defender") || role.equals("Goalkeeper")) {
            stayPositioned();
        }
    }

    private void performOpponentRole() {
        if (role.equals("Striker")) {
            interceptBall();
        } else if (role.equals("Defender") || role.equals("Goalkeeper")) {
            blockGoal();
        } else if (role.equals("Midfielder")) {
            monitorPlay();
        }
    }

    private void moveToBall() {
        // Placeholder: logic to move towards the ball
        effOut.setJointCommand(RobotConsts.LeftHipPitch, 0.5);
        effOut.setJointCommand(RobotConsts.RightHipPitch, -0.5);
    }

    private boolean isCloseToBall() {
        // Placeholder: logic to determine proximity to the ball
        return true;
    }

    private void kickBall() {
        effOut.setJointCommand(RobotConsts.RightKneePitch, -0.8);
    }

    private void supportKickoff() {
        // Placeholder: logic for midfielders to support during kickoff
        effOut.setJointCommand(RobotConsts.NeckYaw, 0.2);
    }

    private void stayPositioned() {
        // Placeholder: logic for defenders/goalkeepers to hold their positions
        effOut.setJointCommand(RobotConsts.LeftShoulderPitch, 0.0);
    }

    private void interceptBall() {
        // Placeholder: logic for intercepting the ball
        effOut.setJointCommand(RobotConsts.RightFootPitch, 0.5);
    }

    private void blockGoal() {
        // Placeholder: logic for blocking the goal
        effOut.setJointCommand(RobotConsts.LeftArmRoll, -0.3);
    }

    private void monitorPlay() {
        // Placeholder: logic for monitoring the game
        effOut.setJointCommand(RobotConsts.NeckPitch, 0.1);
    }
}
