import java.util.Random;

public class RoboTeam {
    public static void main(String[] args) {
        // Team 1 Robots
        final RoboAgent striker1 = new RoboAgent("1", "team1", -1, 0, 0, "Striker");
        final RoboAgent defender1 = new RoboAgent("2", "team1", -1, 1, 0, "Defender");
        final RoboAgent goalkeeper1 = new RoboAgent("3", "team1", -2, 0, 0, "Goalkeeper");
        final RoboAgent midfielder1 = new RoboAgent("4", "team1", -1, -1, 0, "Midfielder");

        // Team 2 Robots
        final RoboAgent striker2 = new RoboAgent("11", "team2", 1, 0, 180, "Striker");
        final RoboAgent defender2 = new RoboAgent("21", "team2", 1, 1, 180, "Defender");
        final RoboAgent goalkeeper2 = new RoboAgent("31", "team2", 2, 0, 180, "Goalkeeper");
        final RoboAgent midfielder2 = new RoboAgent("41", "team2", 1, -1, 180, "Midfielder");

        // Randomly select the kickoff team
        final String kickoffTeam = getRandomKickoffTeam(); // Declare kickoffTeam as final
        System.out.println("Kickoff team: " + kickoffTeam);

        // Run all robots in separate threads
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                striker1.runAgent(kickoffTeam);
            }
        });
 
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                defender1.runAgent(kickoffTeam);
            }
        });

        Thread t3 = new Thread(new Runnable() {
            @Override
            public void run() {
                goalkeeper1.runAgent(kickoffTeam);
            }
        });

        Thread t4 = new Thread(new Runnable() {
            @Override
            public void run() {
                midfielder1.runAgent(kickoffTeam);
            }
        });

        Thread t5 = new Thread(new Runnable() {
            @Override
            public void run() {
                striker2.runAgent(kickoffTeam);
            }
        });
 
        Thread t6 = new Thread(new Runnable() {
            @Override
            public void run() {
                defender2.runAgent(kickoffTeam);
            }
        });

        Thread t7 = new Thread(new Runnable() {
            @Override
            public void run() {
                goalkeeper2.runAgent(kickoffTeam);
            }
        });

        Thread t8 = new Thread(new Runnable() {
            @Override
            public void run() {
                midfielder2.runAgent(kickoffTeam);
            }
        });

        // Start all threads
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
        t7.start();
        t8.start();
    }

    private static String getRandomKickoffTeam() {
        Random random = new Random();
        return random.nextBoolean() ? "team1" : "team2";
    }
}